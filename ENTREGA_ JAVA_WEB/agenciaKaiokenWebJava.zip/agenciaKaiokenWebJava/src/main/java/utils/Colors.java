package utils;

public class Colors {
	public static final String RESET = "\033[0m";
	public static final String GREEN = "\033[0;32m";
	public static final String RED = "\033[0:31m";	
	
}
